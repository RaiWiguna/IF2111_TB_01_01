#include <stdio.h>
#include "ADT/boolean.h"
#include "ADT/listlinier.h"
#include "ADT/map.h"
#include "ADT/mesinkar.h"
#include "ADT/mesinkata.h"
#include "ADT/stack.h"
#include "ADT/linkedlist.h"

void wishlistAdd();

void wishlistSwap();

void wishlistRemoveNumber();

void wishlistRemove();

void wishlistClear();

void wishlistShow();