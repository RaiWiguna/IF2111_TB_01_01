#include "console.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

void wishlistAdd(LinkedList *L, ElementType item) {
    Address P = First(*L);

    // Cari apakah item sudah ada di wishlist
    while (P != NIL) {
        if (strcmp(Info(P), item) == 0) {
            printf("%s sudah ada di wishlist!\n", item);
            return;
        }
        P = Next(P);
    }

    // Jika belum ada, tambahkan ke wishlist
    InsertLast(L, item);
    printf("Berhasil menambahkan %s ke wishlist!\n", item);
}

void wishlistSwap(LinkedList *L, int i, int j) {
    if (i == j) {
        printf("Gagal menukar posisi, posisi ke-%d dan ke-%d adalah sama.\n", i, j);
        return;
    }

    Address Pi = First(*L), Pj = First(*L);
    int index = 1;

    // Cari elemen ke-i dan ke-j
    while (Pi != NIL && index < i) {
        Pi = Next(Pi);
        index++;
    }
    index = 1;
    while (Pj != NIL && index < j) {
        Pj = Next(Pj);
        index++;
    }

    if (Pi == NIL || Pj == NIL) {
        printf("Gagal menukar posisi! Salah satu indeks tidak valid.\n");
    } else {
        ElementType temp = strdup(Info(Pi));
        free(Info(Pi));
        Info(Pi) = strdup(Info(Pj));
        free(Info(Pj));
        Info(Pj) = temp;

        printf("Berhasil menukar posisi %s dengan %s pada wishlist!\n", Info(Pi), Info(Pj));
    }
}

void wishlistRemoveNumber(LinkedList *L, int index) {
    if (IsListEmpty(*L)) {
        printf("Penghapusan barang WISHLIST gagal dilakukan, WISHLIST kosong!\n");
        return;
    }

    Address P = First(*L);
    int currentIndex = 1;

    // Cari elemen di posisi index
    while (P != NIL && currentIndex < index) {
        P = Next(P);
        currentIndex++;
    }

    if (P == NIL) {
        printf("Penghapusan barang WISHLIST gagal dilakukan, Barang ke-%d tidak ada di WISHLIST!\n", index);
    } else {
        printf("Berhasil menghapus barang posisi ke-%d dari wishlist!\n", index);
        if (P == First(*L)) {
            DeleteFirst(L, &P);
        } else if (P == Last(*L)) {
            DeleteLast(L, &P);
        } else {
            Next(Prev(P)) = Next(P);
            Prev(Next(P)) = Prev(P);
        }
        Deallocate(P);
    }
}

void wishlistRemove(LinkedList *L, ElementType item) {
    Address P = First(*L);

    // Cari elemen berdasarkan item
    while (P != NIL) {
        if (strcmp(Info(P), item) == 0) {
            if (P == First(*L)) {
                DeleteFirst(L, &P);
            } else if (P == Last(*L)) {
                DeleteLast(L, &P);
            } else {
                Next(Prev(P)) = Next(P);
                Prev(Next(P)) = Prev(P);
            }
            printf("%s berhasil dihapus dari WISHLIST!\n", item);
            Deallocate(P);
            return;
        }
        P = Next(P);
    }
    printf("Penghapusan barang WISHLIST gagal dilakukan, %s tidak ada di WISHLIST!\n", item);
}

void wishlistClear(LinkedList *L) {
    Address P;
    while (!IsListEmpty(*L)) {
        DeleteFirst(L, &P);
        Deallocate(P);
    }
    printf("Wishlist telah dikosongkan.\n");
}

void wishlistShow(LinkedList L) {
    if (IsListEmpty(L)) {
        printf("Wishlist kamu kosong!\n");
    } else {
        printf("Berikut adalah isi wishlist-mu:\n");
        Address P = First(L);
        int index = 1;
        while (P != NIL) {
            printf("%d. %s\n", index, Info(P));
            P = Next(P);
            index++;
        }
    }
}