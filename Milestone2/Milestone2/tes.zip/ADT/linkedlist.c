#include "linkedlist.h"
#include <stdio.h>

// Membuat list kosong
void CreateList(LinkedList *L) {
    First(*L) = NIL;
    Last(*L) = NIL;
}

// Mengecek apakah list kosong
bool IsListEmpty(LinkedList L) {
    return First(L) == NIL && Last(L) == NIL;
}

// Alokasi node baru
Address Allocate(ElementType X) {
    Address P = (Node*)malloc(sizeof(Node));
    if (P != NIL) {
        Info(P) = (char*)malloc((strlen(X) + 1) * sizeof(char));
        if (Info(P) != NIL) {
            strcpy(Info(P), X);
            Next(P) = NIL;
            Prev(P) = NIL;
        } else {
            free(P); // Gagal alokasi info
            P = NIL;
        }
    }
    return P;
}

// Dealokasi node
void Deallocate(Address P) {
    if (P != NIL) {
        free(Info(P));
        free(P);
    }
}

// Menambahkan node di awal
void InsertFirst(LinkedList *L, Address P) {
    if (IsListEmpty(*L)) {
        First(*L) = P;
        Last(*L) = P;
    } else {
        Next(P) = First(*L);
        Prev(First(*L)) = P;
        First(*L) = P;
    }
}

// Menambahkan node di akhir
void InsertLast(LinkedList *L, Address P) {
    if (IsListEmpty(*L)) {
        First(*L) = P;
        Last(*L) = P;
    } else {
        Prev(P) = Last(*L);
        Next(Last(*L)) = P;
        Last(*L) = P;
    }
}

// Menghapus node dari awal
void DeleteFirst(LinkedList *L, Address *P) {
    *P = First(*L);
    if (First(*L) == Last(*L)) {
        First(*L) = NIL;
        Last(*L) = NIL;
    } else {
        First(*L) = Next(First(*L));
        Prev(First(*L)) = NIL;
    }
    Next(*P) = NIL;
}

// Menghapus node dari akhir
void DeleteLast(LinkedList *L, Address *P) {
    *P = Last(*L);
    if (First(*L) == Last(*L)) {
        First(*L) = NIL;
        Last(*L) = NIL;
    } else {
        Last(*L) = Prev(Last(*L));
        Next(Last(*L)) = NIL;
    }
    Prev(*P) = NIL;
}

// Mencari elemen di dalam list
Address Search(LinkedList L, ElementType X) {
    Address P = First(L);
    while (P != NIL) {
        if (strcmp(Info(P), X) == 0) {
            return P;
        }
        P = Next(P);
    }
    return NIL;
}

// Mencetak list ke depan
void PrintListForward(LinkedList L) {
    Address P = First(L);
    printf("[");
    while (P != NIL) {
        printf("%s", Info(P));
        if (Next(P) != NIL) {
            printf(", ");
        }
        P = Next(P);
    }
    printf("]\n");
}

// Mencetak list ke belakang
void PrintListBackward(LinkedList L) {
    Address P = Last(L);
    printf("[");
    while (P != NIL) {
        printf("%s", Info(P));
        if (Prev(P) != NIL) {
            printf(", ");
        }
        P = Prev(P);
    }
    printf("]\n");
}
