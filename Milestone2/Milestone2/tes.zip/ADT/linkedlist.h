#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <stdbool.h> // Untuk tipe boolean
#include <stdlib.h>  // Untuk malloc dan free
#include <string.h>  // Untuk manipulasi string

#define NIL NULL

typedef char* ElementType; // Elemen berupa string
typedef struct Node *Address;
typedef struct Node {
    ElementType info;
    Address next;
    Address prev;
} Node;

typedef struct {
    Address first;
    Address last;
} LinkedList;

// Macro untuk mempermudah akses
#define Info(P) (P)->info
#define Next(P) (P)->next
#define Prev(P) (P)->prev
#define First(L) ((L).first)
#define Last(L) ((L).last)

// Prototipe fungsi
void CreateList(LinkedList *L);
bool IsListEmpty(LinkedList L);

Address Allocate(ElementType X);
void Deallocate(Address P);

void InsertFirst(LinkedList *L, Address P);
void InsertLast(LinkedList *L, Address P);
void DeleteFirst(LinkedList *L, Address *P);
void DeleteLast(LinkedList *L, Address *P);

Address Search(LinkedList L, ElementType X);
void PrintListForward(LinkedList L);
void PrintListBackward(LinkedList L);

#endif
