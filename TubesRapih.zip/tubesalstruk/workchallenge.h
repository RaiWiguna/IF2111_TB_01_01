#ifndef WORK_CHALLENGE_H
#define WORK_CHALLENGE_H

#include "user.h"
#include "work.h"

void tebakAngka(User *u);
void WORDL3();

#endif