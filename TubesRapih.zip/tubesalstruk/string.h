#ifndef STRING_H
#define STRING_H

int strcmp(const char* str1, const char* str2);
char* strcpy(char* dest, const char* src);

#endif