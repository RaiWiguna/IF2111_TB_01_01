#ifndef SAVE_COMMANDS_H
#define SAVE_COMMANDS_H

#include "mesinkata.h"
#include "listlinier.h"

void SAVE(char *namafile, TabInt T);
/* menyimpan state ke dalam sebuah file yang terdapat pada folder save
   I.S. : state belum disimpan
   F.S. : state disimpan dalam file yg diberi nama sesuai dengan masukan dari pengguna dan dimuat di dalam folder save */
#endif