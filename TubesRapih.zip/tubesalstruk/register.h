#ifndef REGISTER_H
#define REGISTER_H

#include "mesinkata.h"
#include "listlinier.h"
#include "mesinkar.h"

void Register();
void Login();
void Logout();

#endif