#ifndef HELP_H
#define HELP_H

void Help(int menuState);

#endif