#ifndef QUIT_H
#define QUIT_H

#include "boolean.h"
#include "listlinier.h"

void QUIT(boolean *status, TabInt T);
/* Keluar dari aplikasi setelah save */

#endif
