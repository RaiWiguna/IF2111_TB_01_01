#ifndef STOREREMOVE_H
#define STOREREMOVE_H

#include "arraydin.h"

void storeRemove(arraydin *A);

#endif