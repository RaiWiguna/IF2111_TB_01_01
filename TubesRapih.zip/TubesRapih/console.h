#ifndef console.h
#define console.h

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "../ADT/mesinkata.h"
#include "../ADT/listlinier.h"
#include "../ADT/mesinkar.h"
#include "../ADT/ArrayDinamis.h"
#include "../ADT/scanfile.h"
#include "../ADT/queue.h"

#define MAX_LEN 100 

typedef struct {
    char name[MAX_LEN];
    char password[MAX_LEN];
    int money;
} User;

User users[MAX_LEN];  
int userCount = 0;      
int currentUserIndex = -1;

// Fungsi untuk menyalin string
void copyString(char *dest, const char *src) {
    while ((*dest++ = *src++));
}

// Fungsi untuk membandingkan string
int compareString(const char *str1, const char *str2) {
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }
    return *(unsigned char *)str1 - *(unsigned char *)str2;
}

// Fungsi untuk membuat pengguna baru
void createUser(User *u, char *name, char *password, int money) {
    copyString(u->name, name);
    copyString(u->password, password);
    u->money = money;
}

// Fungsi untuk membandingkan data pengguna
int compareUser(User u, char *username, char *password) {
    return (compareString(u.name, username) == 0 && compareString(u.password, password) == 0);
}

#define MAX_LEN_WORK 50

typedef struct {
    char name[MAX_LEN_WORK];
    int income;
    int duration;
} Job;

Job selectedJob;

void sleep(int second) {
    time_t start_time = time(NULL); // Waktu mulai
    time_t end_time = start_time + second; // Waktu akhir

    while (time(NULL) < end_time) {
        // Loop sampai waktu sekarang melebihi waktu akhir
    }
}

Job jobList[] = {
    {"Evil Lab Assistant", 100, 14},
    {"OWCA Hiring Manager", 4200, 21},
    {"Cikapundunginator Caretaker", 7000, 30},
    {"Mewing Specialist", 10000, 22},
    {"Inator Connoisseur", 997, 15}
};

int jobCount = 5;

int listAngka[] = {80, 11, 63, 51, 83, 15, 31, 7, 94, 73, 8, 42, 12, 53, 43, 53, 53, 21, 44, 6};

void tebakAngka(User *u) {

    srand(time(NULL));
    int hasilrandom = listAngka[rand() % (sizeof(listAngka) / sizeof(listAngka[0]))];

    int found = 0;
    int hadiah = 500;
    int jumlahTebakan = 0;
    int tebakan;
    printf("\n");
    while (found == 0 && jumlahTebakan != 10)
    {
        printf("Tebak angka: ");
        STARTWORD();
        tebakan = atoi(CurrentWord.TabWord);
        if (tebakan < hasilrandom)
        {
            printf("\nTebakanmu lebih kecil!\n");
            hadiah -= 50;
            jumlahTebakan += 1;
        } else if (tebakan > hasilrandom)
        {
            printf("\nTebakanmu lebih besar!\n");
            hadiah -= 50;
            jumlahTebakan += 1;
        } else {
            printf("\nTebakanmu benar! ");
            found = 1;
        }   
    }
    
    if (jumlahTebakan == 10)
    {
        printf("\nAnda gagal! Semoga beruntung di game selanjutnya!");
    } else {
        u->money += hadiah;
        printf("+%d rupiah telah ditambahkan ke akun anda.\n", hadiah);
    }

}

#define WORD_LENGTH 5
#define MAX_ATTEMPTS 5

void getSecretWord(char *secretWord) {
    const char *words[] = {"TUBES", "ARRAY", "INDEX", "QUEUE", "STACK"};
    srand(time(0));
    copyString(secretWord, words[rand() % 5]);
}

void checkGuess(const char *secretWord, const char *guess, char *review) {
    int isUsed[WORD_LENGTH] = {0};

    for (int i = 0; i < WORD_LENGTH; i++) {
        review[i * 2] = guess[i];
        review[i * 2 + 1] = '%';
    }
    review[WORD_LENGTH * 2] = '\0';

    for (int i = 0; i < WORD_LENGTH; i++) {
        if (guess[i] == secretWord[i]) {
            review[i * 2 + 1] = ' ';
            isUsed[i] = 1;
        }
    }
    for (int i = 0; i < WORD_LENGTH; i++) {
        if (review[i * 2 + 1] == '%') {
            for (int j = 0; j < WORD_LENGTH; j++) {
                if (!isUsed[j] && guess[i] == secretWord[j]) {
                    review[i * 2 + 1] = '*';
                    isUsed[j] = 1;
                    break;
                }
            }
        }
    }
}

void printState(char attempts[MAX_ATTEMPTS][WORD_LENGTH * 2 + 1], int attemptCount) {
    for (int i = 0; i < MAX_ATTEMPTS; i++) {
        if (i < attemptCount)
            printf("%s\n", attempts[i]);
        else
            printf("_ _ _ _ _\n");
    }
}

void WORDL3() {
    char secretWord[WORD_LENGTH + 1];
    char attempts[MAX_ATTEMPTS][WORD_LENGTH * 2 + 1] = {{0}};
    int attemptCount = 0;
    
    getSecretWord(secretWord);
    printf("WELCOME TO W0RDL3, YOU HAVE 5 CHANCES TO ANSWER BEFORE YOU LOSE!\n\n");
    printState(attempts, attemptCount);

    while (attemptCount < MAX_ATTEMPTS) {
        printf("\nMasukan kata tebakan Anda: ");
        START();  

        char guess[WORD_LENGTH + 1] = {0};
        int index = 0;

        while (!EOP && index < WORD_LENGTH) {
            guess[index++] = GetCC(); 
            ADV(); 
        }

        if (index != WORD_LENGTH) {
            printf("Invalid input. Please enter a %d-letter word.\n", WORD_LENGTH);
            continue;
        }

        guess[WORD_LENGTH] = '\0'; 

        checkGuess(secretWord, guess, attempts[attemptCount]);
        printf("\nHasil:\n");
        printState(attempts, attemptCount + 1);

        if (compareString(guess, secretWord) == 0) { 
            printf("\nSelamat, Anda menang!\n+1500 rupiah telah ditambahkan ke akun Anda.\n");
            return;
        }

        attemptCount++;
    }

    printf("\nBoo! Anda kalah. The correct word was: %s\n", secretWord);
}

void welcomeMenu() {

}

void loginMenu() {

}

void mainMenu() {

}

void Start(boolean login);/*
    Mengirimkan sebuah text apabila berhasil melakukan load.    
*/

void Load(ArrayDin *Item,boolean *login);/*
    Melakukan Load File
*/

void Login();

void Logout();

void Register();

void Work(User *u);

int workChallenge(User *u);

void storeList(ArrayDin Item);/*
    Menampilkan list store
*/

void storeRequest(Queue *Req, ArrayDin Item); /*
    Melakukan store request;
*/

void storeSupply(Queue Req, ArrayDin *Item); /*
    Menambahkan Suplly, memasukkan kedalam array Store
*/

void storeRemove(ArrayDin *Item);/*
    Melakukan remove item pada store, hanya di remove pada array akan tersimpan apa bila melakukan save.
*/

void Help(int menuState);

void SAVE(char *namafile, TabInt T);

void QUIT(boolean *status, TabInt T);

#endif