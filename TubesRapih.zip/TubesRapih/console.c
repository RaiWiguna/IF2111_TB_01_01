#include "console.h"

void Start(boolean login){
    if(login == true){
        printf("File konfigurasi aplikasi berhasil dibaca. PURRMART berhasil dijalankan.\n");
    }
}

void Load(ArrayDin *Item,boolean *login){
    // Kamus lokal
    Word tempWord;
    char filePath[200];

    // Algoritma Meminta Input
    printf(">> LOAD ");
    STARTWORD();
    StrcpyToWord(&tempWord,CurrentWord.TabWord);

    // membaca file
    sprintf(filePath,"../../../save/%s",tempWord.TabWord);
    ReadFile(filePath,Item);
    (*login)=true;
}

void Login() {
    if (currentUserIndex != -1) {
        printf("Anda masih tercatat sebagai %s, silakan LOGOUT terlebih dahulu!\n", users[currentUserIndex].name);
        return;
    }

    char username[MAX_LEN], password[MAX_LEN];
    printf("Username: ");
    STARTWORD();  
    copyString(username, CurrentWord.TabWord);

    printf("Password: ");
    STARTWORD();  
    copyString(password, CurrentWord.TabWord);

    for (int i = 0; i < userCount; i++) {
        if (compareUser(users[i], username, password)) {
            currentUserIndex = i;
            printf("Anda telah login ke PURRMART sebagai %s.\n", users[i].name);
            return;
        }
    }
    printf("Username atau password salah.\n");
}

void Logout() {
    if (currentUserIndex == -1) {
        printf("Tidak ada pengguna yang sedang login.\n");
        return;
    }

    printf("%s telah logout dari sistem PURRMART. Silakan REGISTER/LOGIN kembali untuk melanjutkan. \n", users[currentUserIndex].name);
    currentUserIndex = -1;
}

void Register() {
    char username[MAX_LEN], password[MAX_LEN];
    printf("Username: ");
    STARTWORD();  
    copyString(username, CurrentWord.TabWord);

    for (int i = 0; i < userCount; i++) {
        if (compareString(users[i].name, username) == 0) {
            printf("Username sudah digunakan. Silakan lakukan REGISTER ulang.\n");
            return;
        }
    }

    printf("Password: ");
    STARTWORD();  
    copyString(password, CurrentWord.TabWord);

    // Tambahkan pengguna baru
    createUser(&users[userCount], username, password, 0); 
    userCount++;
    printf("Akun berhasil dibuat. Silakan LOGIN untuk melanjutkan.\n");
}

void Work(User *u) {

    // Menampilkan daftar pekerjaan
    printf("Daftar Pekerjaan:\n");
    for(int i = 0; i < jobCount; i++) {
        printf("%d. %s (pendapatan=%d, durasi=%ds)\n", i+1, jobList[i].name, jobList[i].income, jobList[i].duration);
    }

    // Input untuk memilih pekerjaan
    printf("\nMasukkan pekerjaan yang dipilih: ");
    STARTWORD();

    // Membuat variabel untuk menentukan mana perkerjaan yang dipilih
    int angkapilihan;
    if(IsSame(CurrentWord.TabWord,"Evil Lab Assistant")) {
        angkapilihan = 0;
    } else if (IsSame(CurrentWord.TabWord,"OWCA Hiring Manager"))
    {
        angkapilihan = 1;
    } else if (IsSame(CurrentWord.TabWord,"Cikapundunginator Caretaker"))
    {
        angkapilihan = 2;
    } else if (IsSame(CurrentWord.TabWord, "Mewing Specialist"))
    {
        angkapilihan = 3;
    } else if (IsSame(CurrentWord.TabWord,"Inator Connoisseur"))
    {
        angkapilihan = 4;
    }

    printf("\nAnda sedang bekerja sebagai %s... harap tunggu.\n", jobList[angkapilihan].name);

    // Pekerjaan diproses
    for (int i = 0; i < jobList[angkapilihan].duration; i++) {
        sleep(1);
    }

    // Pekerjaan selesai
    printf("\nPekerjaan selesai! +%d rupiah telah ditambahkan ke akun Anda.\n", jobList[angkapilihan].income);

    // Income pekerjaan dimasukkan kedalam user money
    u->money += jobList[angkapilihan].income;
}

int workChallenge(User *u) {

    printf("Daftar challenge yang tersedia:\n");
    printf("1. Tebak Angka (biaya main=200)\n");
    printf("2. W0RDL399 (biaya main=500)\n\n");

    printf("Masukan challenge yang hendak dimainkan: ");
    int pilihan;
    STARTWORD();
    pilihan = atoi(CurrentWord.TabWord);
    while (getchar() != '\n');

    if (pilihan == 1)
    {
        if (u->money >= 200) {
                u->money -= 200; // Biaya bermain Tebak Angka
                tebakAngka(&u);
            } else {
                printf("Uang Anda tidak cukup untuk bermain Tebak Angka!\n");
            }
    } else if (pilihan == 2)
    {
        if (u->money >= 200) {
                u->money -= 200; // Biaya bermain Tebak Angka
                WORDL3(&u);
            } else {
                printf("Uang Anda tidak cukup untuk bermain Tebak Angka!\n");
            }
    } else {
        printf("Pilihan tidak valid.\n");
    }

    return 0;
}

void storeList(ArrayDin Item){
    if(Item.Neff == 0){
        printf("TOKO KOSONG\n");
    }
    else{
        printf("List barang yang ada di toko :\n");
        CetakNameArrayDin(Item);
    }
}

void storeRequest(Queue *Req, ArrayDin Item) {
    string input;
    printf("Nama barang yang diminta: ");
    STARTWORD();
    StrcpyToString(&input, &CurrentWord);  // Salin kata yang diminta
    printf("%s input\n", input);

    // Pastikan item tidak ada di antrian dan toko
    if (!IsInQueue(Req, input) && !IsInArrDin(Item, input)) {
        enqueue(Req, input);  // Enqueue item jika tidak ada duplikasi
    } else if (IsInArrDin(Item, input)) {
        printf("Barang dengan nama yang sama sudah ada di toko!\n");
    } else {
        printf("Barang dengan nama yang sama sudah ada di antrian!\n");
    }
    displayQueue(*Req);  // Tampilkan antrian setelah penambahan
}

void storeSupply(Queue Req, ArrayDin *Item) {
    string temp;
    string price;
    Word input;

    dequeue(&Req, &temp);
    printf("Apakah kamu ingin menambahkan barang %s: ", temp);
    STARTWORD();  
    StrcpyToWord(&input, CurrentWord.TabWord);  
    if (IsSame(input.TabWord, "Terima")) {
        printf("Harga barang: ");
        STARTWORD();  
        StrcpyToString(price, &CurrentWord);
        InsertLastArrDin(Item, price, temp); 
        printf("%s dengan harga %s telah ditambahkan ke toko.\n", temp, price);
    } 
    else if (IsSame(input.TabWord, "Tunda")) {
        printf("%s dikembalikan ke antrian.\n", temp);
        enqueue(&Req, temp); 
    } 
    else if (IsSame(input.TabWord, "Tolak")) {
        printf("%s dihapuskan dari antrian.\n", temp);  // Tidak ada tindakan tambahan
    } 
    else if (IsSame(input.TabWord, "Purry")) {
        printf(" < Balik ke menu >\n");
    } 
}

void storeRemove(ArrayDin *Item){
    // Kamus Lokal
    Word input;
    int index;
    // Algoritma
    printf("Nama barang yang akan dihapus: ");
    STARTWORD();
    StrcpyToWord(&input,CurrentWord.TabWord);
    printf("\n");
    if(IsInArrDin(*Item,input.TabWord)){
        index = SearchArrDin(*Item,input.TabWord);
        DeleteAtArrDin(Item,index);
        printf("%s telah berhasil dihapus.\n",input.TabWord);
    }
    else{
        printf("Toko tidak menjual %s.\n",input.TabWord);
    }
}

void Help(int menuState) {
    if (menuState == 1) {
        printf("=====[ Welcome Menu Help PURRMART]=====\n");
        printf("1. START -> Untuk masuk sesi baru\n");
        printf("2. LOAD -> Untuk memulai sesi berdasarkan file konfigurasi\n");
        printf("3. QUIT -> Untuk keluar dari program\n");
    }
    else if (menuState == 2) {
        printf("=====[ Login Menu Help PURRMART]=====\n");
        printf("1. REGISTER -> Untuk melakukan pendaftaran akun baru\n");
        printf("2. LOGIN -> Untuk masuk ke dalam akun dan memulai sesi\n");
        printf("3. QUIT -> Untuk keluar dari program\n");
    }
    else if (menuState == 3) {
        printf("=====[ Menu Help PURRMART]=====\n");
        printf("1. WORK -> Untuk bekerja\n");
        printf("2. WORK CHALLENGE -> Untuk mengerjakan challenge\n");
        printf("3. STORE LIST -> Untuk melihat barang-barang di toko\n");
        printf("4. STORE REQUEST -> Untuk meminta penambahan barang\n");
        printf("5. STORE SUPPLY -> Untuk menambahkan barang dari permintaan\n");
        printf("6. STORE REMOVE -> Untuk menghapus barang\n");
        printf("7. LOGOUT -> Untuk keluar dari sesi\n");
        printf("8. SAVE -> Untuk menyimpan state ke dalam file\n");
        printf("9. QUIT -> Untuk keluar dari program\n");
    }
}

void SAVE(char *namafile, TabInt T) {
    FILE *file;
    char path[100] = "./save/"; 
    int i = 0;

    while (namafile[i] != '\0') {
        path[7 + i] = namafile[i];  
        i++;
    }
    path[7 + i] = '\0';

    printf("Path file: %s\n", path);

    file = fopen(path, "r");
    if (file != NULL) {
        fclose(file);  
        printf("File '%s' sudah ada. Apakah Anda ingin menimpa? (y/n): ", namafile);
        
        STARTWORD_ITEM(stdin); 

        printf("Input yang dibaca: %s\n", CurrentWord1.TabWord);

        if (EndWord || CurrentWord1.Length == 0 || CurrentWord1.TabWord[0] != 'y') {
            printf("Proses penyimpanan dibatalkan.\n");
            return; 
        }
    }

    file = fopen(path, "w");
    if (file == NULL) {
        printf("Error: Tidak dapat membuka file '%s' untuk menulis.\n", namafile);
        return; 
    }

    for (IdxType i = GetFirstIdx(T); i <= GetLastIdx(T); i++) {
        fprintf(file, "%d\n", T[i]);
    }

    fclose(file);
    printf("Save file berhasil disimpan.\n");
}

void QUIT(boolean *status, TabInt T){
    int len = 0; 
    printf("Apakah kamu ingin menyimpan data sesi sekarang (Y/N)? ");

    START();
    printf("\n");

    if (currentChar == 'Y' || currentChar == 'y'){
        char file[1000];
        printf("Menyimpan ke file: ");
        ADV();
        while (currentChar != MARK && len < 1000){
            file[len] = currentChar;
            len++;
            ADV();
        }
        if (len == 0){
            printf("Nama file kosong. Penyimpanan dibatalkan. \n");
        }
        else{
            printf("'%.*s'\n", len, file);
            SAVE(file, T);
            printf("Sesi berhasil disimpan!\n");
        }
    }

    else if(currentChar == 'N' || currentChar == 'n'){
        printf("\nAman aja. Kamu bisa menyimpannya lain kali. \n");
    }
    else{
        printf("\nOops! Sepertinya input kurang tepat. Data tidak disimpan.\n");
    }

    printf("Terima kasih sudah menggunakan PURRMART.\n ");
    printf("See you next time! ^_^\n");

}