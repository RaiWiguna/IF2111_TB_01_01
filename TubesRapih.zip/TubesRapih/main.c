#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "console.h"

void clearTerminal() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

int main(){
    // Kamus Lokal
    User u;
    ArrayDin Item;
    TabInt T;
    Queue Q;
    boolean status = false;
    boolean login =false;
    MakeEmpty(&T);
    MakeArrayDin(&Item);

    // Algoritma
    clearTerminal();
    Welcomemenu();

    string pilihanmenu;
    int menuState = 1, tes=0;
    scanf("%s", pilihanmenu);
    
    while (1)
    {
        if(menuState == 1) {

            printf("\nMasukkan command: ");
            STARTWORD();
            pilihanmenu = CurrentWord.TabWord;

            if (pilihanmenu == "start")
            {
                Start(login);
            }
            else if (pilihanmenu == "load")
            {
                Load(&Item, &login);
            }
            else if(pilihanmenu == "quit")
            {
                QUIT(&status, T);
            }
            else if (pilihanmenu == "help")
            {
                clearTerminal();
                Help(menuState);
            } 
            else {
                printf("Command tidak valid\n");
            }
        } 
        else if (menuState == 2)
        {
            printf("\nMasukkan command: ");
            STARTWORD();
            pilihanmenu = CurrentWord.TabWord;

            if (pilihanmenu == "register")
            {
                Register();
            }
            else if (pilihanmenu == "login")
            {
                Login();
                menuState = 3;
            } 
            else if (pilihanmenu == "help")
            {
                clearTerminal();
                Help(menuState);
            } 
            else {
                printf("Command tidak valid\n");
            }

        } 
        else if (menuState == 3)
        {
            printf("\nMasukkan command: ");
            STARTWORD();
            pilihanmenu = CurrentWord.TabWord;

            if (pilihanmenu == "work")
            {
                Work(&u);
            } 
            else if (pilihanmenu == "work challenge")
            {
                workChallenge(&u);
            } 
            else if(pilihanmenu == "store list") 
            {
                storeList(Item);
            } 
            else if (pilihanmenu == "store request")
            {
                storeRequest(&Q, Item);
            } 
            else if (pilihanmenu == "store supply")
            {
                storeSupply(Q, &Item);
            } 
            else if (pilihanmenu == "store remove")
            {
                storeRemove(&Item);
            } 
            else if (pilihanmenu == "logout")
            {
                Logout();
                menuState = 2;
            } 
            else if (pilihanmenu == "save") {
                printf("Masukkan nama file untuk menyimpan data: ");
                string filename;
                STARTWORD();
                filename = CurrentWord.TabWord;
                SAVE(filename, T);
            }
            else if (pilihanmenu == "quit")
            {
                // quit();
                break;
            } 
            else if (pilihanmenu == "help")
            {
                clearTerminal();
                Help(menuState);
            } 
            else {
                printf("Command tidak valid\n");
            }

        }
    }
}
